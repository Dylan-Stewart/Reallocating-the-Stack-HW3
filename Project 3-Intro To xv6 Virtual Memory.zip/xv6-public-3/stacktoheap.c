#include "types.h"
#include "stat.h"
#include "user.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "elf.h"

  
// Prevent this function from being optimized, which might give it closed form
#pragma GCC push_options // These pragmas maintain a stack of the current target and optimization options. It is intended for include files where you temporarily want to switch to using a different ‘#pragma GCC target’ or ‘#pragma GCC optimize’ and then to pop back to the previous options.
#pragma GCC optimize ("O0") // Use all functions as a single region. This typically results in the smallest code size, and is enabled by default for -Os or -O0.
#pragma GCC pop_options

static int
HeapOverwrite(int a)
{
char * pointer = (char * )(KERNBASE - 1 );
for (int i = 0; i < a; i++){
  *pointer = 'a';
  pointer = pointer - PGSIZE;
  printf(1, "Step: %d\n", i);
 }
  return a;
}
int
main(int argc, char *argv[])
{
  int a, b;

  if(argc != 2){ // checking if we submit 2 arguments
    printf(1, "Usage: %s levels\n", argv[0]);
    exit();
  }

  a = atoi(argv[1]);
  b = HeapOverwrite(a);
  printf(1, "result %d\n", b);
  exit();
}
